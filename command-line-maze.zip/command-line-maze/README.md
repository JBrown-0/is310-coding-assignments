Last login: Mon Sep  9 20:06:47 on ttys001
justinbrown@Justins-MacBook-Air-8 ~ % cd path-to-your/is310-coding-assignments

cd: no such file or directory: path-to-your/is310-coding-assignments
justinbrown@Justins-MacBook-Air-8 ~ % mkdir is310-coding-assignments/command-line-maze
cd is310-coding-assignments/command-line-maze

justinbrown@Justins-MacBook-Air-8 command-line-maze % mkdir -p ~/is310-coding-assignments/command-line-maze
cd ~/is310-coding-assignments/command-line-maze

justinbrown@Justins-MacBook-Air-8 command-line-maze % ls

justinbrown@Justins-MacBook-Air-8 command-line-maze % mkdir entrance
mkdir entrance/level1
mkdir entrance/level1/level2
touch entrance/level1/level2/solution.txt
mkdir hidden_directory
touch hidden_directory/.hidden_file

justinbrown@Justins-MacBook-Air-8 command-line-maze % # Go to the maze directory 
cd ~/is310-coding-assignments/command-line-maze

# List directories and files to confirm structure
ls -R

zsh: command not found: #
zsh: command not found: #
entrance		hidden_directory

./entrance:
level1

./entrance/level1:
level2

./entrance/level1/level2:
solution.txt

./hidden_directory:
justinbrown@Justins-MacBook-Air-8 command-line-maze % nano README.md

justinbrown@Justins-MacBook-Air-8 command-line-maze % justinbrown@Justins-MacBook-Air-8 ~ % cd path-to-your/is310-coding-assignments
zsh: command not found: justinbrown@Justins-MacBook-Air-8
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % cd: no such file or directory: path-to-your/is310-coding-assignments
zsh: command not found: cd:
justinbrown@Justins-MacBook-Air-8 command-line-maze % justinbrown@Justins-MacBook-Air-8 ~ % mkdir is310-coding-assignments/command-line-maze
zsh: command not found: justinbrown@Justins-MacBook-Air-8
justinbrown@Justins-MacBook-Air-8 command-line-maze % cd is310-coding-assignments/command-line-maze
cd: no such file or directory: is310-coding-assignments/command-line-maze
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % justinbrown@Justins-MacBook-Air-8 command-line-maze % mkdir -p ~/is310-coding-assignments/command-line-maze
zsh: command not found: justinbrown@Justins-MacBook-Air-8
justinbrown@Justins-MacBook-Air-8 command-line-maze % cd ~/is310-coding-assignments/command-line-maze
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % justinbrown@Justins-MacBook-Air-8 command-line-maze % ls
zsh: command not found: justinbrown@Justins-MacBook-Air-8
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % justinbrown@Justins-MacBook-Air-8 command-line-maze % mkdir entrance
zsh: command not found: justinbrown@Justins-MacBook-Air-8
justinbrown@Justins-MacBook-Air-8 command-line-maze % mkdir entrance/level1
mkdir: entrance/level1: File exists
justinbrown@Justins-MacBook-Air-8 command-line-maze % mkdir entrance/level1/level2
mkdir: entrance/level1/level2: File exists
justinbrown@Justins-MacBook-Air-8 command-line-maze % touch entrance/level1/level2/solution.txt
justinbrown@Justins-MacBook-Air-8 command-line-maze % mkdir hidden_directory
mkdir: hidden_directory: File exists
justinbrown@Justins-MacBook-Air-8 command-line-maze % touch hidden_directory/.hidden_file

justinbrown@Justins-MacBook-Air-8 command-line-maze % # Go to the maze directory 
cd ~/is310-coding-assignments/command-line-maze

# List directories and files to confirm structure
ls -R

zsh: command not found: #
zsh: command not found: #
entrance		hidden_directory

./entrance:
level1

./entrance/level1:
level2

./entrance/level1/level2:
solution.txt

./hidden_directory:
justinbrown@Justins-MacBook-Air-8 command-line-maze % nano README.md


  UW PICO 5.09                    File: README.md                     Modified  

git init
git add .
git commit -m "Add Command Line Corn Maze"

git remote add origin <your-repo-url>
git push -u origin main

git remote -v











File Name to write : README.md                                                  
^G Get Help  ^T  To Files                                                     
^C Cancel    TAB Complete                                                     
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % justinbrown@Justins-MacBook-Air-8 command-line-maze % # Go to the maze directory 
zsh: command not found: justinbrown@Justins-MacBook-Air-8
justinbrown@Justins-MacBook-Air-8 command-line-maze % cd ~/is310-coding-assignments/command-line-maze
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % # List directories and files to confirm structure
zsh: command not found: #
justinbrown@Justins-MacBook-Air-8 command-line-maze % ls -R
README.mdLast login: Mon Sep  9 20:06:47 on ttys001
entrance
hidden_directory

./entrance:
level1

./entrance/level1:
level2

./entrance/level1/level2:
solution.txt

./hidden_directory:
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % zsh: command not found: #
zsh: command not found: zsh:
justinbrown@Justins-MacBook-Air-8 command-line-maze % zsh: command not found: #
zsh: command not found: zsh:
justinbrown@Justins-MacBook-Air-8 command-line-maze % entrancehidden_directory
zsh: command not found: entrancehidden_directory
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % ./entrance:
zsh: no such file or directory: ./entrance:
justinbrown@Justins-MacBook-Air-8 command-line-maze % level1
zsh: command not found: level1
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % ./entrance/level1:
zsh: no such file or directory: ./entrance/level1:
justinbrown@Justins-MacBook-Air-8 command-line-maze % level2
zsh: command not found: level2
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % ./entrance/level1/level2:
zsh: no such file or directory: ./entrance/level1/level2:
justinbrown@Justins-MacBook-Air-8 command-line-maze % solution.txt
zsh: command not found: solution.txt
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % ./hidden_directory:
zsh: no such file or directory: ./hidden_directory:
justinbrown@Justins-MacBook-Air-8 command-line-maze % justinbrown@Justins-MacBook-Air-8 command-line-maze % nano README.md
zsh: command not found: justinbrown@Justins-MacBook-Air-8
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze %   UW PICO 5.09                    File: README.md                     Modified  
zsh: command not found: UW
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % git init
Initialized empty Git repository in /Users/justinbrown/is310-coding-assignments/command-line-maze/.git/
justinbrown@Justins-MacBook-Air-8 command-line-maze % git add .
justinbrown@Justins-MacBook-Air-8 command-line-maze % git commit -m "Add Command Line Corn Maze"
[main (root-commit) 29248a3] Add Command Line Corn Maze
 Committer: Justin Brown <justinbrown@Justins-MacBook-Air-8.local>
Your name and email address were configured automatically based
on your username and hostname. Please check that they are accurate.
You can suppress this message by setting them explicitly. Run the
following command and follow the instructions in your editor to edit
your configuration file:

    git config --global --edit

After doing this, you may fix the identity used for this commit with:

    git commit --amend --reset-author

 3 files changed, 90 insertions(+)
 create mode 100644 README.mdLast login: Mon Sep  9 20:06:47 on ttys001
 create mode 100644 entrance/level1/level2/solution.txt
 create mode 100644 hidden_directory/.hidden_file
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % git remote add origin <your-repo-url>
zsh: parse error near `\n'
justinbrown@Justins-MacBook-Air-8 command-line-maze % git push -u origin main
fatal: 'origin' does not appear to be a git repository
fatal: Could not read from remote repository.

Please make sure you have the correct access rights
and the repository exists.
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % git remote -v
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % 
justinbrown@Justins-MacBook-Air-8 command-line-maze % File Name to write : README.md                                                  
Name:      cannot open `Name' (No such file or directory)
to:        cannot open `to' (No such file or directory)
write:     cannot open `write' (No such file or directory)
::         cannot open `:' (No such file or directory)
README.md: cannot open `README.md' (No such file or directory)
justinbrown@Justins-MacBook-Air-8 command-line-maze % ^G Get Help  ^T  To Files                                                     
zsh: substitution failed
justinbrown@Justins-MacBook-Air-8 command-line-maze % ^C Cancel    TAB Complete                                                     
zsh: substitution failed
justinbrown@Justins-MacBook-Air-8 command-line-maze % git remote add origin https://github.com/JBrown-0/is310-coding-assignments.git
justinbrown@Justins-MacBook-Air-8 command-line-maze % git push -u origin main
Username for 'https://github.com': JBrown-0
Password for 'https://JBrown-0@github.com': 
remote: Invalid username or password.
fatal: Authentication failed for 'https://github.com/JBrown-0/is310-coding-assignments.git/'
justinbrown@Justins-MacBook-Air-8 command-line-maze % git remote add origin https://github.com/JBrown-0/is310-coding-assignments.git
error: remote origin already exists.
justinbrown@Justins-MacBook-Air-8 command-line-maze % git push -u origin main
Username for 'https://github.com': JBrown-0
Password for 'https://JBrown-0@github.com': 
remote: Support for password authentication was removed on August 13, 2021.
remote: Please see https://docs.github.com/get-started/getting-started-with-git/about-remote-repositories#cloning-with-https-urls for information on currently recommended modes of authentication.
fatal: Authentication failed for 'https://github.com/JBrown-0/is310-coding-assignments.git/'
justinbrown@Justins-MacBook-Air-8 command-line-maze % git remote add origin https://github.com/JBrown-0/is310-coding-assignments.git
error: remote origin already exists.
justinbrown@Justins-MacBook-Air-8 command-line-maze % git push -u origin main
Username for 'https://github.com': JBrown-0
Password for 'https://JBrown-0@github.com': 
remote: Permission to JBrown-0/is310-coding-assignments.git denied to JBrown-0.
fatal: unable to access 'https://github.com/JBrown-0/is310-coding-assignments.git/': The requested URL returned error: 403
justinbrown@Justins-MacBook-Air-8 command-line-maze % git push -u origin main
Username for 'https://github.com': JBrown-0
Password for 'https://JBrown-0@github.com': 
remote: Permission to JBrown-0/is310-coding-assignments.git denied to JBrown-0.
fatal: unable to access 'https://github.com/JBrown-0/is310-coding-assignments.git/': The requested URL returned error: 403
justinbrown@Justins-MacBook-Air-8 command-line-maze % # Navigate to the is310-coding-assignments directory
cd ~/is310-coding-assignments

# Add the remote repository (if not already done)
git remote add origin https://github.com/JBrown-0/is310-coding-assignments.git

# Push the changes to the remote repository
git push -u origin main
zsh: command not found: #
zsh: unknown file attribute: i
error: remote origin already exists.
zsh: command not found: #
branch 'main' set up to track 'origin/main'.
Everything up-to-date
justinbrown@Justins-MacBook-Air-8 is310-coding-assignments % 
